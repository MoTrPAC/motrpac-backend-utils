# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['motrpac_backend_utils',
 'motrpac_backend_utils.proto',
 'motrpac_backend_utils.zipper']

package_data = \
{'': ['*']}

install_requires = \
['google-auth>=2.6.6,<3.0.0',
 'google-cloud-logging>=3.0.0,<4.0.0',
 'google-cloud-pubsub>=2.12.0,<3.0.0',
 'google-cloud-storage>=2.3.0,<3.0.0',
 'opentelemetry-api>=1.11.1,<2.0.0',
 'opentelemetry-exporter-gcp-trace>=1.3.0,<2.0.0',
 'opentelemetry-instrumentation-requests>=0.30b1,<0.31',
 'opentelemetry-instrumentation-urllib3>=0.30b1,<0.31',
 'opentelemetry-propagator-gcp>=1.3.0,<2.0.0',
 'opentelemetry-sdk>=1.11.1,<2.0.0',
 'protobuf>=3.20.1,<4.0.0',
 'psutil>=5.9.0,<6.0.0',
 'requests>=2.24.0,<3.0.0',
 'smart-open>=6.0.0,<7.0.0']

setup_kwargs = {
    'name': 'motrpac-backend-utils',
    'version': '0.1.4',
    'description': '',
    'long_description': None,
    'author': 'Mihir Samdarshi',
    'author_email': 'msamdars@stanford.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
